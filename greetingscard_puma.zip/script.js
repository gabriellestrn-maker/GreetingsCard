let kategoriYangDipilih = "";

function pilihKategori(kategori) {
  kategoriYangDipilih = kategori;

  document.getElementById("halaman-1").style.display = "none";
  document.getElementById("halaman-2").style.display = "block";
  document.getElementById("judul-form").innerText = "Greeting Card: " + kategori;

  if (kategori === "Custom") {
    document.getElementById("field-custom").style.display = "block";
    document.getElementById("info-template").style.display = "none";
  } else {
    document.getElementById("field-custom").style.display = "none";
    document.getElementById("info-template").style.display = "block";
  }
}

function prosesKartu() {
  let penerima = document.getElementById("inputPenerima").value;
  let pengirim = document.getElementById("inputPengirim").value;
  let email = document.getElementById("inputEmail").value;
  let pesanCustom = document.getElementById("inputPesanCustom").value;

  if (penerima === "") {
    alert("Recipient name cannot be empty!");
    return;
  }

  if (kategoriYangDipilih === "Custom" && pesanCustom === "") {
    alert("Custom message cannot be empty!");
    return;
  }

  if (email.includes("@gmail.com") === false) {
    alert("Error: Email must use a @gmail.com address!");
    return;
  }

  let isiPesan = "";
  let classTemplate = "";

  if (kategoriYangDipilih === "Birthday") {
    isiPesan = "Happy birthday " + penerima + "! May you always be healthy, surrounded by good things and good people, and may all your wishes come true! Be happy <3";
    classTemplate = "template-birthday";
  } else if (kategoriYangDipilih === "Anniversary") {
    isiPesan = "Happy anniversary " + penerima + "! Thank you for all the wonderful memories and love shared. May your days ahead be filled with endless joy, deeper love, and perpetual happiness!";
    classTemplate = "template-anniversary";
  } else if (kategoriYangDipilih === "Graduation") {
    isiPesan = "Happy graduation " + penerima + "! So proud of your hard work and incredible achievement. May this milestone be the beginning of a brilliant journey toward all your dreams!";
    classTemplate = "template-graduation";
  } else if (kategoriYangDipilih === "Custom") {
    isiPesan = pesanCustom;
    classTemplate = "template-custom";
  }

  if (pengirim === "") {
    pengirim = "Anonymous";
  }

  document.getElementById("tampilPenerima").innerText = "To: " + penerima;
  document.getElementById("tampilPesan").innerText = '"' + isiPesan + '"';
  document.getElementById("tampilPengirim").innerText = "From: " + pengirim;
  document.getElementById("tampilEmail").innerText = "Card successfully sent to: " + email;

  document.getElementById("desainKartu").className = "kartu-template " + classTemplate;

  document.getElementById("halaman-2").style.display = "none";
  document.getElementById("halaman-3").style.display = "block";
}

function selesai() {
  alert("Greeting card successfully sent!");
  kembaliKeAwal();
}

function kembaliKeAwal() {
  document.getElementById("inputPenerima").value = "";
  document.getElementById("inputPengirim").value = "";
  document.getElementById("inputEmail").value = "";
  document.getElementById("inputPesanCustom").value = "";

  document.getElementById("halaman-2").style.display = "none";
  document.getElementById("halaman-3").style.display = "none";
  document.getElementById("halaman-1").style.display = "block";
}